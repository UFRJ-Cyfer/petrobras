
separationIndexes.indexSP = 897;
separationIndexes.indexPI = 1300;
timeWindow = 2^14;
minAcceptableAmplitude = 3.5e-4;
PIRemainsIndex = 1492;
normalized = 2;

mainVallen = loadData('Idr02_02_ciclo1_1.mat', timeWindow, ...
    minAcceptableAmplitude, separationIndexes,PIRemainsIndex);

vallenFigureHandles = plotData(mainVallen);

corrInputClasses = correlationAnalysis(mainVallen);

corrFigureHandles = plotCorr(corrInputClasses);


energyDirectCorrFigHandles = plotDirectCorr(corrInputClasses,mainVallen.frequencyVector, normalized);
energyCrossCorrFigHandles = plotCrossCorr(corrInputClasses,mainVallen.frequencyVector, normalized);
phaseCorrFigHandles = plotPhaseCorr(corrInputClasses,mainVallen.frequencyVector);
